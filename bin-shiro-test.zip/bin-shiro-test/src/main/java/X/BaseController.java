package X;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BaseController {

	@RequestMapping({ "**/**", "/**", "**", "/index" })
	public ModelAndView getXPage(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("*******************");
		System.out.println(request.getPathInfo());
		return new ModelAndView(request.getPathInfo());
	}

	public BaseController() {
		super();
		System.err.println("初始化");
	}

}
