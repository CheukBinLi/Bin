package com.alexgaoyh.test.dao;

import com.alexgaoyh.common.dao.BaseDao;
import com.alexgaoyh.test.entity.TestEntity;

public interface TestDao extends BaseDao<TestEntity> {

}
